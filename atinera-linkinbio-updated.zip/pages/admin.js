import db from '../lib/db';

export async function getServerSideProps() {
  const payments = db.prepare("SELECT COUNT(*) AS count FROM stats WHERE type='payment'").get();
  const clicks = db.prepare("SELECT pseudo, COUNT(*) AS count FROM stats WHERE type='click' GROUP BY pseudo ORDER BY count DESC").all();

  return {
    props: {
      payments: payments.count,
      clicks,
    },
  };
}

export default function Admin({ payments, clicks }) {
  return (
    <div style={{ padding: '20px', fontFamily: 'Arial, sans-serif', backgroundColor: '#121212', color: 'white', minHeight: '100vh' }}>
      <h1>Dashboard Atinera - Statistiques</h1>
      <p><strong>Nombre total de paiements réussis :</strong> {payments}</p>

      <h2>Clics par pseudo</h2>
      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr>
            <th style={{ borderBottom: '1px solid white', textAlign: 'left', padding: '8px' }}>Pseudo</th>
            <th style={{ borderBottom: '1px solid white', textAlign: 'left', padding: '8px' }}>Nombre de clics</th>
          </tr>
        </thead>
        <tbody>
          {clicks.map(({ pseudo, count }) => (
            <tr key={pseudo}>
              <td style={{ borderBottom: '1px solid #444', padding: '8px' }}>{pseudo}</td>
              <td style={{ borderBottom: '1px solid #444', padding: '8px' }}>{count}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}