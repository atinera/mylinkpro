import db from '../../lib/db';

export async function getServerSideProps({ params, res }) {
  const pseudo = params.pseudo;

  db.prepare("INSERT INTO stats (type, pseudo) VALUES (?, ?)").run('click', pseudo);

  res.writeHead(302, { Location: \`https://allmylink.com/\${pseudo}\` });
  res.end();

  return { props: {} };
}

export default function Redirect() {
  return null;
}