export default function Cancel() {
  return (
    <div style={{
      backgroundColor: '#121212',
      color: 'white',
      height: '100vh',
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      flexDirection: 'column',
      fontFamily: 'Arial, sans-serif',
      padding: '20px'
    }}>
      <h1>Paiement annulé</h1>
      <p>Tu peux réessayer quand tu veux.</p>
    </div>
  );
}