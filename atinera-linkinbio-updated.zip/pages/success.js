export default function Success() {
  return (
    <div style={{
      backgroundColor: '#121212',
      color: 'white',
      height: '100vh',
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      flexDirection: 'column',
      fontFamily: 'Arial, sans-serif',
      padding: '20px'
    }}>
      <h1>Paiement réussi !</h1>
      <p>Merci pour ton abonnement Atinera. Tu peux maintenant personnaliser ton lien.</p>
    </div>
  );
}